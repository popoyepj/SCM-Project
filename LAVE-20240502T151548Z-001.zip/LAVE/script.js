document.querySelector('.img-btn').addEventListener('click', function()
	{
		document.querySelector('.cont').classList.toggle('s-signup')
	}
);
function myfunction(){
	alert("You are signed up successfully")
}
function myfunction2(){
	alert("You are signed in successfully")
}
